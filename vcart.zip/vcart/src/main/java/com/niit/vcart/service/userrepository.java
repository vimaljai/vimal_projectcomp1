package com.niit.vcart.service;

import org.jboss.logging.Param;
import org.springframework.stereotype.Repository;

import com.niit.vcart.details.Userdetails;
@Repository("userrepository")
public interface userrepository extends JpaRepository<Userdetails, Long> {


	  @Query("select s from user s where s.userName = :Userdetails")
	  Userdetails findByUserName(@Param("User") String Userdetails);

	
}
