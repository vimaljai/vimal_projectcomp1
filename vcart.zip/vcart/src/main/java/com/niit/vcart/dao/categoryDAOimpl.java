package com.niit.vcart.dao;


import java.util.List;
import java.util.Locale.Category;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.vcart.details.Categorydetails;


	
	
	@Repository("categoryDAO")
	public class categoryDAOimpl implements CategoryDAO {
		

		@Autowired
		private SessionFactory sessionFactory;


		public categoryDAOimpl(SessionFactory sessionFactory) {
			this.sessionFactory = sessionFactory;
		}

		@Transactional
		public List<Categorydetails> list() {
			
			@SuppressWarnings("unchecked")
			List<Categorydetails> listCategorydetails = (List<Categorydetails>) 
			          sessionFactory.getCurrentSession()
					.createCriteria(Categorydetails.class)
					.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

			return listCategorydetails;
		}

		@Transactional
		public void saveOrUpdate(Categorydetails category) {
			sessionFactory.getCurrentSession().saveOrUpdate(category);
		}

		@Transactional
		public void delete(String id) {
			Categorydetails CategoryToDelete = new Categorydetails();
			CategoryToDelete.setId(id);
			sessionFactory.getCurrentSession().delete(CategoryToDelete);
		}

		@Transactional
		public Categorydetails get(String id) {
			String hql = "from Category where id=" + "'"+ id +"'";
			Query query = sessionFactory.getCurrentSession().createQuery(hql);
			
			@SuppressWarnings("unchecked")
			List<Categorydetails> listCategory = (List<Categorydetails>) query.list();
			
			if (listCategory != null && !listCategory.isEmpty()) {
				return listCategory.get(0);
			}
			
			return null;
		}
		
		
		@Transactional
		public Categorydetails getByName(String name) {
			String hql = "from Category where name=" + "'"+ name +"'";
			Query query = sessionFactory.getCurrentSession().createQuery(hql);
			
			@SuppressWarnings("unchecked")
			List<Categorydetails> listCategory = (List<Categorydetails>) query.list();
			
			if (listCategory != null && !listCategory.isEmpty()) {
				return listCategory.get(0);
			}
			
			return null;
		}


	}

