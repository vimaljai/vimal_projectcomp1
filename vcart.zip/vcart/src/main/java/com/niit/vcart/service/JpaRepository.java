package com.niit.vcart.service;

public interface JpaRepository<T1, T2> {

}
