package com.niit.vcart.service;

import java.io.File;

import javax.naming.Context;

import org.apache.catalina.LifecycleException;
import org.apache.catalina.LifecycleListener;
import org.apache.catalina.LifecycleState;
import org.apache.catalina.Server;
import org.apache.catalina.deploy.NamingResourcesImpl;
import org.apache.catalina.startup.Catalina;
import org.h2.engine.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.niit.vcart.details.Userdetails;


	@Service("userservice")
	public class serviceimpl implements Server {
	@Autowired
	private userrepository userrepository;
	@Transactional
	public User save(User user) {
	return userrepository.save(Username);
	}
	public boolean findByLogin(String userName, String password) {
	User user = userrepository.findByUserName(user);
	if(user != null && user.getPassword.equals(password)) {
	return true;
	}
	return false;
	}
	public boolean findByUserName(String userName) {
	Userdetails userdetails = userrepository.findByUserName(userName);
	if( userdetails != null) {
	return true;
	}
	return false;
	}
	public void addLifecycleListener(LifecycleListener arg0) {
		// TODO Auto-generated method stub
		
	}
	public void destroy() throws LifecycleException {
		// TODO Auto-generated method stub
		
	}
	public LifecycleListener[] findLifecycleListeners() {
		// TODO Auto-generated method stub
		return null;
	}
	public LifecycleState getState() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getStateName() {
		// TODO Auto-generated method stub
		return null;
	}
	public void init() throws LifecycleException {
		// TODO Auto-generated method stub
		
	}
	public void removeLifecycleListener(LifecycleListener arg0) {
		// TODO Auto-generated method stub
		
	}
	public void start() throws LifecycleException {
		// TODO Auto-generated method stub
		
	}
	public void stop() throws LifecycleException {
		// TODO Auto-generated method stub
		
	}
	public void addService(org.apache.catalina.Service arg0) {
		// TODO Auto-generated method stub
		
	}
	public void await() {
		// TODO Auto-generated method stub
		
	}
	public org.apache.catalina.Service findService(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}
	public org.apache.catalina.Service[] findServices() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getAddress() {
		// TODO Auto-generated method stub
		return null;
	}
	public Catalina getCatalina() {
		// TODO Auto-generated method stub
		return null;
	}
	public File getCatalinaBase() {
		// TODO Auto-generated method stub
		return null;
	}
	public File getCatalinaHome() {
		// TODO Auto-generated method stub
		return null;
	}
	public Context getGlobalNamingContext() {
		// TODO Auto-generated method stub
		return null;
	}
	public NamingResourcesImpl getGlobalNamingResources() {
		// TODO Auto-generated method stub
		return null;
	}
	public Object getNamingToken() {
		// TODO Auto-generated method stub
		return null;
	}
	public ClassLoader getParentClassLoader() {
		// TODO Auto-generated method stub
		return null;
	}
	public int getPort() {
		// TODO Auto-generated method stub
		return 0;
	}
	public String getShutdown() {
		// TODO Auto-generated method stub
		return null;
	}
	public void removeService(org.apache.catalina.Service arg0) {
		// TODO Auto-generated method stub
		
	}
	public void setAddress(String arg0) {
		// TODO Auto-generated method stub
		
	}
	public void setCatalina(Catalina arg0) {
		// TODO Auto-generated method stub
		
	}
	public void setCatalinaBase(File arg0) {
		// TODO Auto-generated method stub
		
	}
	public void setCatalinaHome(File arg0) {
		// TODO Auto-generated method stub
		
	}
	public void setGlobalNamingResources(NamingResourcesImpl arg0) {
		// TODO Auto-generated method stub
		
	}
	public void setParentClassLoader(ClassLoader arg0) {
		// TODO Auto-generated method stub
		
	}
	public void setPort(int arg0) {
		// TODO Auto-generated method stub
		
	}
	public void setShutdown(String arg0) {
		// TODO Auto-generated method stub
		
	}
	}	