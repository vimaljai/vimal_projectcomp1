package com.niit.vcart.dao;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetails;

import com.niit.vcart.details.User;
import com.niit.vcart.details.Userdetails;

public interface UserDAO {

	
	
	

	public List<Userdetails> list();

	public Userdetails get(String id);

	public void saveOrUpdate(User user);
	
	public void saveOrUpdate(UserDetails userDetails);

	public void delete(String id);
	
	public boolean isValidUser(String id, String name, boolean isAdmin);


}


