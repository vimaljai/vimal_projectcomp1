package com.niit.vcart.dao;

import com.niit.vcart.details.productdetails;

public interface ProductDAO {


	public java.util.List<productdetails> list();

	public productdetails get(String id);

	public void saveOrUpdate(productdetails productdetails);

	public void delete(String id);


}
