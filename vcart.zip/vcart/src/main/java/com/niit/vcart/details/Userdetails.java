package com.niit.vcart.details;


import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Table;

import org.hibernate.annotations.Entity;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="REGISTER")
public class Userdetails {
	@javax.persistence.Id
	
	@GeneratedValue
	@Column
	public String Id;
	@Column
	@NotEmpty
	private String F_name;
	@Column
	@NotEmpty
	private String L_name;
	@Column
	@NotEmpty
		private String E_id;
	@Column
	@NotEmpty
	private String password;
	@Column
	@NotEmpty
	private String C_password;
		protected String getId() {
			return Id;
		}
		public void setId(String id) {
			Id = id;
		}
		protected String getF_name() {
			return F_name;
		}
		protected void setF_name(String f_name) {
			F_name = f_name;
		}
		protected String getL_name() {
			return L_name;
		}
		protected void setL_name(String l_name) {
			L_name = l_name;
		}
		protected String getE_id() {
			return E_id;
		}
		protected void setE_id(String e_id) {
			E_id = e_id;
		}
		protected String getPassword() {
			return password;
		}
		protected void setPassword(String password) {
			this.password = password;
		}
		protected String getC_password() {
			return C_password;
		}
		protected void setC_password(String c_password) {
			C_password = c_password;
		}}

