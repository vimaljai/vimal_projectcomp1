package com.niit.vcart.dao;

import java.util.List;

import com.niit.vcart.details.Categorydetails;

public interface CategoryDAO {


	public List<Categorydetails> list();

	public Categorydetails get(String id);
	
	public Categorydetails getByName(String name);

	public void saveOrUpdate(Categorydetails categorydetails);

	public void delete(String id);


}
