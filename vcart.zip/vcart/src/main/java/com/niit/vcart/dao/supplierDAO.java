package com.niit.vcart.dao;


import java.util.List;

import com.niit.vcart.details.supplierdetails;

public interface supplierDAO {

	


	public List<supplierdetails> list();

	public supplierdetails get(String id);
	
	public supplierdetails getByName(String name);

	public void saveOrUpdate(supplierdetails supplierdetails);

	public String delete(String id);


}

