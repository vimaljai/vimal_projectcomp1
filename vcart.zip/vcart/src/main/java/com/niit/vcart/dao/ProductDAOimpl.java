package com.niit.vcart.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.vcart.details.productdetails;

@Repository("productDAO")
public class ProductDAOimpl {
	
	
	

		

		@Autowired
		private SessionFactory sessionFactory;


		public void ProductDAOImpl(SessionFactory sessionFactory) {
			this.sessionFactory = sessionFactory;
		}

		@Transactional
		public List<productdetails> list() {
			@SuppressWarnings("unchecked")
			List<productdetails> listProduct = (List<productdetails>) sessionFactory.getCurrentSession()
					.createCriteria(productdetails.class)
					.setResultTransformer(Criteria.DISTINCT_ROOT_ENTITY).list();

			return listProduct;
		}

		@Transactional
		public void saveOrUpdate(productdetails product) {
			sessionFactory.getCurrentSession().saveOrUpdate(product);
		}

		@Transactional
		public void delete(String id) {
			productdetails ProductToDelete = new productdetails();
			ProductToDelete.setId(id);
			sessionFactory.getCurrentSession().delete(ProductToDelete);
		}

		@Transactional
		public productdetails get(String id) {
			String hql = "from Product where id='" + id+"'";
			Query query = sessionFactory.getCurrentSession().createQuery(hql);
			
			@SuppressWarnings("unchecked")
			List<productdetails> listProduct = (List<productdetails>) query.list();
			
			if (listProduct != null && !listProduct.isEmpty()) {
				return listProduct.get(0);
			}
			
			return null;
		}


	}



