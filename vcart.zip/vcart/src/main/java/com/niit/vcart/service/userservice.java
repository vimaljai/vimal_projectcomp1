package com.niit.vcart.service;

import org.h2.engine.User;

public interface userservice {

	
	
	
	public interface UserService {
		  User save(User user);
		  boolean findByLogin(String userName, String password);
		  boolean findByUserName(String userName);
		}
}
