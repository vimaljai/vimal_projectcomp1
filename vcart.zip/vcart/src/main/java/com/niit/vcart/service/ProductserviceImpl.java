package com.niit.vcart.service;

import org.hibernate.mapping.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.niit.vcart.details.productdetails;

@Service
public class ProductserviceImpl {

	@Autowired
	private ProductserviceImpl imp;
	
@Transactional
	public void add(productdetails pd) {
		// TODO Auto-generated method stub
	System.out.println("Name inside the service!!!!!!"+pd.getName());
		imp.add(pd);
		
	}
@Transactional
	public void edit(productdetails pd) {
		// TODO Auto-generated method stub
	imp.edit(pd);
		
	}
@Transactional
	public void delete(int pid) {
		// TODO Auto-generated method stub
		
		imp.delete(pid);
		
	}
		
	public List getallproductdetails() {
		// TODO Auto-generated method stub
		return imp.getallproductdetails();
	}

}
