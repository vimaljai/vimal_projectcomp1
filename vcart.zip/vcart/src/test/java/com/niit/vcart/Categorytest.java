package com.niit.vcart;

import java.util.List;
import java.util.Locale.Category;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.vcart.dao.CategoryDAO;
import com.niit.vcart.details.Categorydetails;

public class Categorytest {
	
	
	public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shopingcart");
		context.refresh();
		
	Categorydetails categorydetails =(Categorydetails)	  context.getBean("category");
	
	CategoryDAO categoryDAO = (CategoryDAO)  context.getBean("categoryDAO");
	
/*	
	c.setId("TAB_003");
	c.setName("Tablet");
	c.setDescription("Tablet product");
	
	
	categoryDAO.saveOrUpdate(c);
	*/
	
	
	
	List<Categorydetails>  list =    categoryDAO.list();
	
	for(Categorydetails cat : list)
	{
		System.out.println(cat.getId()  + ":" +  cat.getName()  + ":"+  cat.getDescription());
	}
		
		
	}

}
