package com.niit.vcart;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
//import org.springframework.security.core.userdetails.User;

import com.niit.vcart.dao.UserDAO;
import com.niit.vcart.details.User;


public class Test {
	
	static AnnotationConfigApplicationContext context;
	
	public Test()
	{
		context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.shopingcart");
		context.refresh();
	}
	
	public static void createUser(User user)
	{
		
		UserDAO  userDAO =  (UserDAO) context.getBean("userDAO");
		userDAO.saveOrUpdate(user);
		
		
	}
	
	

	public static void main(String[] args) {
		
		Test t = new Test();
		
		User user =(User)  context.getBean("user");
		user.setId("NIIT");
		user.setPassword("pass");
		user.setAdmin(true);
		
		
		t.createUser(user);
		
		
	}

	

}
